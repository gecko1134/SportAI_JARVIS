git init
git add .
git commit -m "Final deploy"
git branch -M main
git remote add origin https://github.com/yourorg/venture-north-admin.git
git push -u origin main