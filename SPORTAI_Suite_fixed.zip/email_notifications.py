import streamlit as st
def run():
    st.title("📧 Email Notification System")
    st.success("Email alerts and SendGrid integration is ready.")